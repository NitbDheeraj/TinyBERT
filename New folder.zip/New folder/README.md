---
license: apache-2.0
inference: false
---

# Info

This is the model [mistralai/Mistral-7B-Instruct-v0.2](https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.2) which I cut all the intermediate(feed_forward_length) size with 14336 down to 3072, resulting in a ~2.81B model.

It's necessary to pre-train this model, cause at the moment is generating just gibberish.