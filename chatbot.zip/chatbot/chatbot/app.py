import logging
from flask import Flask, render_template, request, jsonify
from chat import get_response

# Set up logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

app = Flask(__name__)

@app.get("/")
def index_get():
    return render_template("base.html")

@app.post("/predict")
def predict():
    text = request.get_json().get("message")
    logging.debug(f'Received message: {text}')  # Log the received message
    response = get_response(text)
    logging.debug(f'Response: {response}')  # Log the response
    return jsonify(response)  # Ensure you return the response object as JSON

if __name__ == "__main__":
    app.run(debug=True)
